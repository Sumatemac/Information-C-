﻿
Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub OpenWindow(sender As Object, e As EventArgs)
        Dim url As String = "Popup.aspx"
        Dim s As String = "window.open('" & url + "', 'popup_window', 'width=300,height=100,left=100,top=100,resizable=yes');"
        ClientScript.RegisterStartupScript(Me.GetType(), "script", s, True)
    End Sub
End Class
