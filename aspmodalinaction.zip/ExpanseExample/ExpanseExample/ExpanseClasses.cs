namespace ExpanseExample
{
    partial class Expanse
    {
    }
}
